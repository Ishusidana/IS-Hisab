IS HISAB — ANDROIDIDE PACKAGE

1) Extract the ZIP.
2) Open the folder named IS-Hisab in AndroidIDE.
3) The correct project root contains settings.gradle.kts.
4) Use JDK 17.
5) Use a compatible Gradle 8.x version; 8.11.x is suitable for AGP 8.9.1.
6) Install Android SDK Platform 36.
7) Sync the project.
8) Build Debug APK.

APK path:
app/build/outputs/apk/debug/app-debug.apk

Detailed phone instructions are in ANDROIDIDE_SETUP.md.
