# IS Hisab — GitHub APK Build

This project is prepared for building the debug APK with GitHub Actions from a phone.

## GitHub upload
1. Create a GitHub repository, for example `IS-Hisab`.
2. Upload the **contents of this IS-Hisab folder** to the repository root. Do not upload the outer ZIP folder as a nested project folder.
3. Make sure `.github/workflows/build-apk.yml` is present in the repository.
4. Open **Actions** → **Build IS Hisab APK** → **Run workflow**.
5. When the workflow finishes successfully, open the run and download the artifact **IS-Hisab-debug-apk**.

The workflow installs Java 17, Android SDK 36, Gradle 8.11.1, builds `:app:assembleDebug`, and uploads the APK as a GitHub Actions artifact.
