package com.`is`.hisab

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.`is`.hisab.data.*
import com.`is`.hisab.ui.ISHisabTheme
import kotlinx.coroutines.launch

private enum class Screen(val title: String) {
    DASHBOARD("Dashboard"), COMPANIES("Companies"), STOCK("Stock"),
    CUSTOMERS("Customers"), LEDGERS("Ledgers"), VOUCHERS("Vouchers"),
    REPORTS("Reports"), SETTINGS("Settings")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ISHisabApp((application as ISHisabApplication).db) }
    }
}

@Composable
private fun ISHisabApp(db: AppDatabase) {
    val scope = rememberCoroutineScope()
    val prefs = remember { db.appContextPrefs() }
    var pin by remember { mutableStateOf(prefs.pin) }
    var dark by remember { mutableStateOf(prefs.dark) }
    var locked by remember { mutableStateOf(pin != null) }
    var screen by remember { mutableStateOf(Screen.DASHBOARD) }
    var currentCompanyId by remember { mutableLongStateOf(prefs.companyId ?: 0L) }

    val companies by db.companyDao().observeAll().collectAsState(initial = emptyList())
    val currentCompany = companies.firstOrNull { it.id == currentCompanyId } ?: companies.firstOrNull()

    LaunchedEffect(companies) {
        if (currentCompanyId == 0L && companies.isNotEmpty()) currentCompanyId = companies.first().id
    }

    ISHisabTheme(dark) {
        if (locked) {
            PinLockScreen(
                hasPin = pin != null,
                expectedPin = pin,
                onCreatePin = { newPin ->
                    prefs.pin = newPin
                    pin = newPin
                    locked = false
                },
                onUnlock = { entered -> if (entered == pin) locked = false }
            )
        } else {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = { Text("${screen.title}${currentCompany?.let { " • ${it.name}" } ?: ""}") },
                        actions = {
                            IconButton(onClick = { locked = true }) { Icon(Icons.Default.Lock, "Lock") }
                        }
                    )
                },
                bottomBar = {
                    NavigationBar {
                        NavigationBarItem(
                            selected = screen == Screen.DASHBOARD,
                            onClick = { screen = Screen.DASHBOARD },
                            icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") }
                        )
                        NavigationBarItem(
                            selected = screen == Screen.STOCK,
                            onClick = { screen = Screen.STOCK },
                            icon = { Icon(Icons.Default.Inventory2, null) }, label = { Text("Stock") }
                        )
                        NavigationBarItem(
                            selected = screen == Screen.CUSTOMERS,
                            onClick = { screen = Screen.CUSTOMERS },
                            icon = { Icon(Icons.Default.People, null) }, label = { Text("Parties") }
                        )
                        NavigationBarItem(
                            selected = screen == Screen.VOUCHERS,
                            onClick = { screen = Screen.VOUCHERS },
                            icon = { Icon(Icons.Default.ReceiptLong, null) }, label = { Text("Vouchers") }
                        )
                        NavigationBarItem(
                            selected = screen == Screen.SETTINGS,
                            onClick = { screen = Screen.SETTINGS },
                            icon = { Icon(Icons.Default.Settings, null) }, label = { Text("More") }
                        )
                    }
                }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (screen) {
                        Screen.DASHBOARD -> Dashboard(
                            db, currentCompany?.id, onNavigate = { screen = it }
                        )
                        Screen.COMPANIES -> Companies(db, currentCompany?.id, { id ->
                            currentCompanyId = id; prefs.companyId = id
                        })
                        Screen.STOCK -> Stock(db, currentCompany?.id)
                        Screen.CUSTOMERS -> Customers(db, currentCompany?.id)
                        Screen.LEDGERS -> Ledgers(db, currentCompany?.id)
                        Screen.VOUCHERS -> Vouchers(db, currentCompany?.id)
                        Screen.REPORTS -> Reports(db, currentCompany?.id)
                        Screen.SETTINGS -> Settings(
                            dark = dark,
                            onDark = { dark = it; prefs.dark = it },
                            onPinReset = { pin = null; prefs.pin = null; locked = false },
                            onScreen = { screen = it }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PinLockScreen(
    hasPin: Boolean,
    expectedPin: String?,
    onCreatePin: (String) -> Unit,
    onUnlock: (String) -> Unit
) {
    var entered by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(
            painterResource(com.`is`.hisab.R.drawable.is_hisab_logo),
            contentDescription = "IS Hisab",
            Modifier.size(150.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text("IS Hisab", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(if (hasPin) "Enter 4 or 6 digit PIN" else "Create a 4 or 6 digit app PIN")
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = entered, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) entered = it },
            label = { Text(if (hasPin) "PIN" else "New PIN") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            visualTransformation = PasswordVisualTransformation(),
            singleLine = true
        )
        if (!hasPin) {
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = confirm, onValueChange = { if (it.length <= 6 && it.all(Char::isDigit)) confirm = it },
                label = { Text("Confirm PIN") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true
            )
        }
        if (error.isNotEmpty()) Text(error, color = MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(16.dp))
        Button(onClick = {
            if (entered.length !in listOf(4, 6)) error = "PIN must be exactly 4 or 6 digits"
            else if (!hasPin && entered != confirm) error = "PINs do not match"
            else if (hasPin) {
                if (entered == expectedPin) onUnlock(entered) else error = "Wrong PIN"
            } else onCreatePin(entered)
        }) { Text(if (hasPin) "Unlock" else "Save PIN") }
    }
}

@Composable
private fun Dashboard(db: AppDatabase, companyId: Long?, onNavigate: (Screen) -> Unit) {
    if (companyId == null) {
        EmptyState("Create your first company to start.")
        return
    }
    val sales by db.voucherDao().sales(companyId).collectAsState(initial = 0.0)
    val purchases by db.voucherDao().purchases(companyId).collectAsState(initial = 0.0)
    val low by db.itemDao().observeLowStock(companyId).collectAsState(initial = emptyList())
    val items by db.itemDao().observe(companyId).collectAsState(initial = emptyList())
    val customers by db.customerDao().observe(companyId).collectAsState(initial = emptyList())

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Accounts & Business Dashboard", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item { StatRow("Sales", "₹ %.2f".format(sales), Icons.Default.TrendingUp) }
        item { StatRow("Purchase", "₹ %.2f".format(purchases), Icons.Default.ShoppingCart) }
        item { StatRow("Stock Items", items.size.toString(), Icons.Default.Inventory2) }
        item { StatRow("Customers / Parties", customers.size.toString(), Icons.Default.People) }
        if (low.isNotEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("LOW STOCK ALERT", fontWeight = FontWeight.Bold)
                        low.take(5).forEach { Text("• ${it.name}: ${it.currentQty} ${it.unit}") }
                    }
                }
            }
        }
        item { Text("Quick Entry", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                QuickButton("Sales", Icons.Default.PointOfSale) { onNavigate(Screen.VOUCHERS) }
                QuickButton("Purchase", Icons.Default.ShoppingCart) { onNavigate(Screen.VOUCHERS) }
                QuickButton("Receipt", Icons.Default.Payments) { onNavigate(Screen.VOUCHERS) }
            }
        }
        item { Text("Modules", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ModuleButton("Companies", "Create / edit / delete / lock company", Icons.Default.Business) { onNavigate(Screen.COMPANIES) }
                ModuleButton("Ledgers", "Accounts, groups and opening balances", Icons.Default.AccountBalance) { onNavigate(Screen.LEDGERS) }
                ModuleButton("Reports", "Sales, purchase and voucher summary", Icons.Default.Assessment) { onNavigate(Screen.REPORTS) }
            }
        }
    }
}

@Composable private fun StatRow(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(32.dp))
            Spacer(Modifier.width(14.dp))
            Column { Text(label); Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        }
    }
}
@Composable private fun QuickButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.weight(1f)) { Icon(icon, null); Spacer(Modifier.width(4.dp)); Text(label) }
}
@Composable private fun ModuleButton(label: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(30.dp))
            Spacer(Modifier.width(12.dp))
            Column { Text(label, fontWeight = FontWeight.Bold); Text(sub, style = MaterialTheme.typography.bodySmall) }
        }
    }
}
@Composable private fun EmptyState(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(text, style = MaterialTheme.typography.titleMedium) }
}

@Composable
private fun Companies(db: AppDatabase, currentId: Long?, onSelect: (Long) -> Unit) {
    val companies by db.companyDao().observeAll().collectAsState(initial = emptyList())
    var show by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Company?>(null) }
    var confirmDelete by remember { mutableStateOf<Company?>(null) }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Button(onClick = { edit = null; show = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Create Company") } }
        items(companies) { c ->
            Card {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = c.id == currentId, onClick = { if (!c.isLocked) onSelect(c.id) })
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.Bold)
                        Text(if (c.isLocked) "🔒 Company Locked" else "FY: 01 April – 31 March")
                    }
                    IconButton(onClick = { edit = c; show = true }) { Icon(Icons.Default.Edit, null) }
                    IconButton(onClick = { confirmDelete = c }) { Icon(Icons.Default.Delete, null) }
                }
            }
        }
    }
    if (show) CompanyDialog(
        initial = edit,
        onDismiss = { show = false },
        onSave = { c -> kotlinx.coroutines.GlobalScope.launch { if (c.id == 0L) db.companyDao().insert(c) else db.companyDao().update(c) }; show = false }
    )
    confirmDelete?.let { c ->
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete company?") },
            text = { Text("All company data can become inaccessible. This action cannot be undone.") },
            confirmButton = {
                TextButton(onClick = { kotlinx.coroutines.GlobalScope.launch { db.companyDao().delete(c) }; confirmDelete = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun CompanyDialog(initial: Company?, onDismiss: () -> Unit, onSave: (Company) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var gstin by remember { mutableStateOf(initial?.gstin ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var locked by remember { mutableStateOf(initial?.isLocked ?: false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Create Company" else "Edit Company") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Company Name") }, singleLine = true)
                OutlinedTextField(address, { address = it }, label = { Text("Address") }, singleLine = true)
                OutlinedTextField(gstin, { gstin = it }, label = { Text("GSTIN") }, singleLine = true)
                OutlinedTextField(phone, { phone = it }, label = { Text("Phone") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(locked, { locked = it }); Spacer(Modifier.width(8.dp)); Text("Lock Company")
                }
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(Company(initial?.id ?: 0, name, address, gstin, phone, isLocked = locked)) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun Stock(db: AppDatabase, companyId: Long?) {
    if (companyId == null) { EmptyState("Select or create a company first."); return }
    val itemsList by db.itemDao().observe(companyId).collectAsState(initial = emptyList())
    var show by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Item?>(null) }
    var del by remember { mutableStateOf<Item?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = { edit = null; show = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add Stock Item") }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(itemsList) { item ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(item.name, fontWeight = FontWeight.Bold)
                            Text("${item.currentQty} ${item.unit}  • Sale ₹${item.saleRate}")
                            if (item.lowStockLevel > 0 && item.currentQty <= item.lowStockLevel)
                                Text("LOW STOCK", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                        }
                        IconButton(onClick = { edit = item; show = true }) { Icon(Icons.Default.Edit, null) }
                        IconButton(onClick = { del = item }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
    }
    if (show) ItemDialog(edit, companyId, { show = false }, { value ->
        kotlinx.coroutines.GlobalScope.launch { if (value.id == 0L) db.itemDao().insert(value) else db.itemDao().update(value) }
        show = false
    })
    del?.let { item ->
        DeleteDialog("Delete stock item?", { kotlinx.coroutines.GlobalScope.launch { db.itemDao().delete(item) }; del = null }, { del = null })
    }
}

@Composable
private fun ItemDialog(initial: Item?, companyId: Long, onDismiss: () -> Unit, onSave: (Item) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var sku by remember { mutableStateOf(initial?.sku ?: "") }
    var qty by remember { mutableStateOf((initial?.currentQty ?: 0.0).toString()) }
    var purchase by remember { mutableStateOf((initial?.purchaseRate ?: 0.0).toString()) }
    var sale by remember { mutableStateOf((initial?.saleRate ?: 0.0).toString()) }
    var low by remember { mutableStateOf((initial?.lowStockLevel ?: 0.0).toString()) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(if (initial == null) "Add Stock Item" else "Edit Stock Item") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Item Name") }, singleLine = true)
                OutlinedTextField(sku, { sku = it }, label = { Text("SKU / Item Code") }, singleLine = true)
                OutlinedTextField(qty, { qty = it }, label = { Text("Current Qty") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(purchase, { purchase = it }, label = { Text("Purchase Rate") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(sale, { sale = it }, label = { Text("Sale Rate") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(low, { low = it }, label = { Text("Low Stock Alert At") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(Item(initial?.id ?: 0, companyId, name, sku, currentQty = qty.toDoubleOrNull() ?: 0.0, purchaseRate = purchase.toDoubleOrNull() ?: 0.0, saleRate = sale.toDoubleOrNull() ?: 0.0, lowStockLevel = low.toDoubleOrNull() ?: 0.0)) }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun Customers(db: AppDatabase, companyId: Long?) {
    if (companyId == null) { EmptyState("Select or create a company first."); return }
    val list by db.customerDao().observe(companyId).collectAsState(initial = emptyList())
    var show by remember { mutableStateOf(false) }; var edit by remember { mutableStateOf<Customer?>(null) }; var del by remember { mutableStateOf<Customer?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = { edit = null; show = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Add Customer / Party") }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { c ->
                Card {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Text(c.name, fontWeight = FontWeight.Bold); Text("${c.phone}  • ${c.balanceType} ₹${c.openingBalance}") }
                        IconButton(onClick = { edit = c; show = true }) { Icon(Icons.Default.Edit, null) }
                        IconButton(onClick = { del = c }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
    }
    if (show) CustomerDialog(edit, companyId, { show = false }, { value ->
        kotlinx.coroutines.GlobalScope.launch { if (value.id == 0L) db.customerDao().insert(value) else db.customerDao().update(value) }; show = false
    })
    del?.let { c -> DeleteDialog("Delete customer?", { kotlinx.coroutines.GlobalScope.launch { db.customerDao().delete(c) }; del = null }, { del = null }) }
}

@Composable
private fun CustomerDialog(initial: Customer?, companyId: Long, onDismiss: () -> Unit, onSave: (Customer) -> Unit) {
    var name by remember { mutableStateOf(initial?.name ?: "") }; var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }; var gst by remember { mutableStateOf(initial?.gstin ?: "") }
    var balance by remember { mutableStateOf((initial?.openingBalance ?: 0.0).toString()) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initial == null) "Add Customer" else "Edit Customer") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            OutlinedTextField(name,{name=it},label={Text("Name")},singleLine=true)
            OutlinedTextField(phone,{phone=it},label={Text("Phone")},singleLine=true)
            OutlinedTextField(address,{address=it},label={Text("Address")},singleLine=true)
            OutlinedTextField(gst,{gst=it},label={Text("GSTIN")},singleLine=true)
            OutlinedTextField(balance,{balance=it},label={Text("Opening Balance")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
        }
    }, confirmButton = { TextButton(onClick={ if(name.isNotBlank()) onSave(Customer(initial?.id ?: 0,companyId,name,phone,address,gst,balance.toDoubleOrNull()?:0.0)) }){Text("Save")} },
       dismissButton={TextButton(onClick=onDismiss){Text("Cancel")}})
}

@Composable
private fun Ledgers(db: AppDatabase, companyId: Long?) {
    if (companyId == null) { EmptyState("Select or create a company first."); return }
    val list by db.ledgerDao().observe(companyId).collectAsState(initial = emptyList())
    var name by remember { mutableStateOf("") }; var group by remember { mutableStateOf("Sundry Debtors") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Ledger Accounts", style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
        Row(verticalAlignment=Alignment.CenterVertically) {
            OutlinedTextField(name,{name=it},label={Text("Ledger name")},modifier=Modifier.weight(1f),singleLine=true)
            Spacer(Modifier.width(8.dp))
            Button(onClick={if(name.isNotBlank()){kotlinx.coroutines.GlobalScope.launch{db.ledgerDao().insert(Ledger(companyId=companyId,name=name,groupName=group))};name=""}}){Text("Add")}
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(list){l->Card{Row(Modifier.fillMaxWidth().padding(12.dp)){Column{Text(l.name,fontWeight=FontWeight.Bold);Text(l.groupName)}}}}}
    }
}

@Composable
private fun Vouchers(db: AppDatabase, companyId: Long?) {
    if (companyId == null) { EmptyState("Select or create a company first."); return }
    val list by db.voucherDao().observe(companyId).collectAsState(initial = emptyList())
    var type by remember { mutableStateOf("SALES") }; var party by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    val types = listOf("SALES","PURCHASE","RECEIPT","PAYMENT","JOURNAL","CONTRA","CREDIT_NOTE","DEBIT_NOTE")
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Voucher Entry", style=MaterialTheme.typography.titleLarge, fontWeight=FontWeight.Bold)
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){ types.take(4).forEach{ t -> FilterChip(selected=type==t,onClick={type=t},label={Text(t)}) } }
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){ types.drop(4).forEach{ t -> FilterChip(selected=type==t,onClick={type=t},label={Text(t)}) } }
        OutlinedTextField(party,{party=it},label={Text("Party / Ledger")},modifier=Modifier.fillMaxWidth(),singleLine=true)
        OutlinedTextField(amount,{amount=it},label={Text("Amount")},modifier=Modifier.fillMaxWidth(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
        Button(onClick={if((amount.toDoubleOrNull()?:0.0)>0){kotlinx.coroutines.GlobalScope.launch{db.voucherDao().insert(Voucher(companyId=companyId,voucherNo="${type.take(3)}-${System.currentTimeMillis()%100000}",type=type,partyName=party,amount=amount.toDouble()))};party="";amount=""}},modifier=Modifier.fillMaxWidth()){Text("Save Voucher")}
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){items(list){v->Card{Row(Modifier.fillMaxWidth().padding(12.dp)){Column(Modifier.weight(1f)){Text("${v.type} • ${v.voucherNo}",fontWeight=FontWeight.Bold);Text(v.partyName)}Text("₹ %.2f".format(v.amount),fontWeight=FontWeight.Bold)}}}}
    }
}

@Composable
private fun Reports(db: AppDatabase, companyId: Long?) {
    if (companyId == null) { EmptyState("Select or create a company first."); return }
    val sales by db.voucherDao().sales(companyId).collectAsState(initial=0.0)
    val purchases by db.voucherDao().purchases(companyId).collectAsState(initial=0.0)
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
        Text("Reports",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        ReportCard("Sales Register", "Total sales recorded", "₹ %.2f".format(sales))
        ReportCard("Purchase Register", "Total purchase recorded", "₹ %.2f".format(purchases))
        ReportCard("Gross Difference", "Sales - Purchase", "₹ %.2f".format(sales-purchases))
        Text("Next expansion: Trial Balance, P&L, Balance Sheet, GST reports, stock valuation, outstanding ageing, day book and PDF/Excel export.")
    }
}
@Composable private fun ReportCard(title:String,sub:String,value:String){Card{Column(Modifier.fillMaxWidth().padding(16.dp)){Text(title,fontWeight=FontWeight.Bold);Text(sub);Text(value,style=MaterialTheme.typography.headlineSmall)}}}

@Composable
private fun Settings(dark:Boolean,onDark:(Boolean)->Unit,onPinReset:()->Unit,onScreen:(Screen)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item { Text("Settings",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold) }
        item { Card{Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Dark Theme",fontWeight=FontWeight.Bold);Text("Customize app appearance")};Switch(dark,onDark)}}}
        item { ModuleButton("Companies","Multiple company management",Icons.Default.Business){onScreen(Screen.COMPANIES)} }
        item { ModuleButton("Ledgers","Ledger and account masters",Icons.Default.AccountBalance){onScreen(Screen.LEDGERS)} }
        item { ModuleButton("Reports","Accounting reports",Icons.Default.Assessment){onScreen(Screen.REPORTS)} }
        item { OutlinedButton(onClick=onPinReset,modifier=Modifier.fillMaxWidth()){Text("Reset App PIN")} }
        item { Text("Automatic backup runs when the app starts. Backup files are stored in the app's private backups folder and Android device/cloud backup is enabled in the manifest.") }
        item { Text("IS Hisab • Version 1.0.0") }
    }
}

@Composable private fun DeleteDialog(title:String,onDelete:()->Unit,onCancel:()->Unit){
    AlertDialog(onDismissRequest=onCancel,title={Text(title)},text={Text("Please confirm. This record will be deleted.")},confirmButton={TextButton(onClick=onDelete){Text("Delete")}},dismissButton={TextButton(onClick=onCancel){Text("Cancel")}})
}

// Small preference wrapper. Kept here so the project remains easy to understand.
private class Prefs(private val context: android.content.Context) {
    private val p = context.getSharedPreferences("is_hisab_prefs", android.content.Context.MODE_PRIVATE)
    var pin: String? get()=p.getString("pin",null) set(v){p.edit().putString("pin",v).apply()}
    var dark: Boolean get()=p.getBoolean("dark",false) set(v){p.edit().putBoolean("dark",v).apply()}
    var companyId: Long? get()=if(p.contains("companyId"))p.getLong("companyId",0) else null set(v){p.edit().putLong("companyId",v?:0).apply()}
}

private fun AppDatabase.appContextPrefs(): Prefs {
    // RoomDatabase keeps the application context internally; this helper is replaced below
    // by a process-level context holder initialized by ISHisabApplication.
    return Prefs(AppContextHolder.context)
}
object AppContextHolder {
    lateinit var context: android.content.Context
}
