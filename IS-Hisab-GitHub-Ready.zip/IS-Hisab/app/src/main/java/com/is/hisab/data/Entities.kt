package com.`is`.hisab.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "companies")
data class Company(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val address: String = "",
    val gstin: String = "",
    val phone: String = "",
    val financialYearStart: String = "01-04",
    val financialYearEnd: String = "31-03",
    val isLocked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyId: Long,
    val name: String,
    val sku: String = "",
    val unit: String = "PCS",
    val openingQty: Double = 0.0,
    val currentQty: Double = 0.0,
    val purchaseRate: Double = 0.0,
    val saleRate: Double = 0.0,
    val lowStockLevel: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyId: Long,
    val name: String,
    val phone: String = "",
    val address: String = "",
    val gstin: String = "",
    val openingBalance: Double = 0.0,
    val balanceType: String = "RECEIVABLE",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "ledgers")
data class Ledger(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyId: Long,
    val name: String,
    val groupName: String = "Sundry Debtors",
    val openingBalance: Double = 0.0,
    val balanceType: String = "DEBIT",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "vouchers")
data class Voucher(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val companyId: Long,
    val voucherNo: String,
    val type: String, // SALES, PURCHASE, RECEIPT, PAYMENT, JOURNAL, CONTRA, CREDIT_NOTE, DEBIT_NOTE
    val partyName: String = "",
    val date: Long = System.currentTimeMillis(),
    val amount: Double = 0.0,
    val narration: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
