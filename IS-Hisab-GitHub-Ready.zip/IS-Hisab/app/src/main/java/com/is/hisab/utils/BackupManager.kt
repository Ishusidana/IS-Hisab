package com.`is`.hisab.utils

import android.content.Context
import com.`is`.hisab.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupManager(private val context: Context, private val db: AppDatabase) {

    suspend fun createAutoBackup() = withContext(Dispatchers.IO) {
        val backupDir = File(context.filesDir, "backups")
        backupDir.mkdirs()

        val companies = db.companyDao().observeAll().first()
        val root = JSONObject()
        root.put("app", "IS Hisab")
        root.put("backupVersion", 1)
        root.put("createdAt", System.currentTimeMillis())

        val companyArray = JSONArray()
        for (company in companies) {
            val c = JSONObject()
            c.put("id", company.id)
            c.put("name", company.name)
            c.put("address", company.address)
            c.put("gstin", company.gstin)
            c.put("phone", company.phone)
            c.put("isLocked", company.isLocked)

            val items = db.itemDao().observe(company.id).first()
            val itemArray = JSONArray()
            items.forEach {
                itemArray.put(JSONObject().apply {
                    put("id", it.id); put("name", it.name); put("sku", it.sku)
                    put("unit", it.unit); put("currentQty", it.currentQty)
                    put("purchaseRate", it.purchaseRate); put("saleRate", it.saleRate)
                    put("lowStockLevel", it.lowStockLevel)
                })
            }
            c.put("items", itemArray)

            val customers = db.customerDao().observe(company.id).first()
            val customerArray = JSONArray()
            customers.forEach {
                customerArray.put(JSONObject().apply {
                    put("id", it.id); put("name", it.name); put("phone", it.phone)
                    put("address", it.address); put("gstin", it.gstin)
                    put("openingBalance", it.openingBalance); put("balanceType", it.balanceType)
                })
            }
            c.put("customers", customerArray)

            val vouchers = db.voucherDao().observe(company.id).first()
            val voucherArray = JSONArray()
            vouchers.forEach {
                voucherArray.put(JSONObject().apply {
                    put("id", it.id); put("voucherNo", it.voucherNo); put("type", it.type)
                    put("partyName", it.partyName); put("date", it.date)
                    put("amount", it.amount); put("narration", it.narration)
                })
            }
            c.put("vouchers", voucherArray)
            companyArray.put(c)
        }
        root.put("companies", companyArray)

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        File(backupDir, "IS_Hisab_auto_$stamp.json").writeText(root.toString(2))

        // Keep the newest 365 daily/automatic backup files.
        backupDir.listFiles()?.sortedByDescending { it.lastModified() }?.drop(365)?.forEach { it.delete() }
    }
}
