package com.`is`.hisab.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CompanyDao {
    @Query("SELECT * FROM companies ORDER BY name")
    fun observeAll(): Flow<List<Company>>
    @Query("SELECT * FROM companies WHERE id = :id LIMIT 1")
    suspend fun get(id: Long): Company?
    @Insert suspend fun insert(company: Company): Long
    @Update suspend fun update(company: Company)
    @Delete suspend fun delete(company: Company)
}

@Dao
interface ItemDao {
    @Query("SELECT * FROM items WHERE companyId = :companyId ORDER BY name")
    fun observe(companyId: Long): Flow<List<Item>>
    @Insert suspend fun insert(item: Item): Long
    @Update suspend fun update(item: Item)
    @Delete suspend fun delete(item: Item)
    @Query("SELECT * FROM items WHERE companyId=:companyId AND currentQty <= lowStockLevel AND lowStockLevel > 0 ORDER BY name")
    fun observeLowStock(companyId: Long): Flow<List<Item>>
    @Query("SELECT COUNT(*) FROM items WHERE companyId=:companyId")
    suspend fun count(companyId: Long): Int
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers WHERE companyId = :companyId ORDER BY name")
    fun observe(companyId: Long): Flow<List<Customer>>
    @Insert suspend fun insert(customer: Customer): Long
    @Update suspend fun update(customer: Customer)
    @Delete suspend fun delete(customer: Customer)
}

@Dao
interface LedgerDao {
    @Query("SELECT * FROM ledgers WHERE companyId=:companyId ORDER BY name")
    fun observe(companyId: Long): Flow<List<Ledger>>
    @Insert suspend fun insert(ledger: Ledger): Long
    @Update suspend fun update(ledger: Ledger)
    @Delete suspend fun delete(ledger: Ledger)
}

@Dao
interface VoucherDao {
    @Query("SELECT * FROM vouchers WHERE companyId=:companyId ORDER BY date DESC, id DESC")
    fun observe(companyId: Long): Flow<List<Voucher>>
    @Insert suspend fun insert(voucher: Voucher): Long
    @Delete suspend fun delete(voucher: Voucher)
    @Query("SELECT COALESCE(SUM(amount),0) FROM vouchers WHERE companyId=:companyId AND type='SALES'")
    fun sales(companyId: Long): Flow<Double>
    @Query("SELECT COALESCE(SUM(amount),0) FROM vouchers WHERE companyId=:companyId AND type='PURCHASE'")
    fun purchases(companyId: Long): Flow<Double>
}
