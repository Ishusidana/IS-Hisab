package com.`is`.hisab

import android.app.Application
import com.`is`.hisab.data.AppDatabase
import com.`is`.hisab.utils.BackupManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class ISHisabApplication : Application() {
    val db by lazy { AppDatabase.get(this) }
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        AppContextHolder.context = applicationContext
        appScope.launch {
            BackupManager(this@ISHisabApplication, db).createAutoBackup()
        }
    }
}
