package com.`is`.hisab.ui

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Blue = Color(0xFF0B4F8A)
private val Green = Color(0xFF4CAF50)

@Composable
fun ISHisabTheme(dark: Boolean = false, content: @Composable () -> Unit) {
    val lightScheme = lightColorScheme(
        primary = Blue,
        secondary = Green,
        tertiary = Color(0xFF176B9D)
    )
    val darkScheme = darkColorScheme(
        primary = Color(0xFF72B7F2),
        secondary = Color(0xFF8BD58F),
        tertiary = Color(0xFF83CFFF)
    )
    MaterialTheme(
        colorScheme = if (dark) darkScheme else lightScheme,
        typography = Typography(),
        content = content
    )
}
