# IS Hisab – AKS Enterprises

Android Studio project for **IS Hisab**.

- Application ID: `com.is.hisab`
- Company: AKS Enterprises
- Minimum Android: 8.0 (API 26)
- Compile/Target SDK: 36
- Kotlin: 2.1.20
- Android Gradle Plugin: 8.9.1
- Jetpack Compose + Material 3
- Room database

## Open in Android Studio
1. Extract this ZIP.
2. Open the **IS-Hisab** root folder (the folder containing `settings.gradle.kts`). Do not open `app` directly.
3. Use **JDK 17 / Embedded JDK** in Gradle settings.
4. Let Gradle Sync finish.
5. If Android Studio shows a **Sync Now** button, click it.
6. Run on a physical Android device or an emulator.

## Important
The project uses Kotlin 2.x Compose compiler support through `org.jetbrains.kotlin.plugin.compose`. No accounting feature was removed to fix the previous sync/manifest errors.

## Included foundation
PIN lock (4/6 digits), multiple companies, company lock flag, stock, low-stock alerts, customers/parties, ledgers, vouchers, reports, dark theme, logo, Room database, and automatic JSON backup at app startup.
