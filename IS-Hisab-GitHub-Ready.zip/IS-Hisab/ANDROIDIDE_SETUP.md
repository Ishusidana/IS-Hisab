# IS Hisab — AndroidIDE Setup

This project is prepared to be opened on an Android phone using AndroidIDE.

## Important
- Open the **IS-Hisab** folder itself — the folder containing `settings.gradle.kts`.
- Do NOT open the `app` folder as the project root.
- Package/namespace/application ID remain `com.is.hisab`.
- Kotlin source packages use `com.`is`.hisab` because `is` is a Kotlin keyword.
- Java/JVM target is 17.
- Compile/target SDK is 36.

## AndroidIDE steps
1. Install/open AndroidIDE.
2. Extract this ZIP using the phone's file manager.
3. In AndroidIDE choose **Open Existing Project** (wording can vary by version).
4. Select the extracted `IS-Hisab` folder — the one containing `settings.gradle.kts`.
5. Allow AndroidIDE to import/sync the Gradle project.
6. If AndroidIDE asks for a Gradle version, use a Gradle 8.x version compatible with Android Gradle Plugin 8.9.1 (8.11.x is suitable).
7. If it asks for a JDK, select JDK 17.
8. Make sure Android SDK Platform 36 and a compatible build-tools version are installed.
9. Wait for dependency downloads and Gradle sync to finish.
10. Use **Build > Assemble Debug** (or the equivalent Build/Run action in your AndroidIDE version).
11. The debug APK will be under:
   `app/build/outputs/apk/debug/app-debug.apk`

## If AndroidIDE asks for Gradle wrapper
This project intentionally does not bundle the Gradle distribution. AndroidIDE can manage/download the Gradle version from its Gradle settings. If your AndroidIDE version requires a wrapper, create/select a Gradle 8.11.x wrapper from its Gradle tools and then sync.

## Do not change these while troubleshooting
- Do not rename the package `com.is.hisab`.
- Do not remove Compose, Room, DataStore, or the existing app modules just to bypass an error.
- If a sync error appears, copy the exact first red error line and send it to me.
